Pin_feb2002 (February 2002) is the same as Pin_july2000 with the
following exceptions:

Changes to Ozone:
----------------
Replaced (fake) O3 in "myp20" with new fake O3 (low amount)
Replaced (fake) O3 in "myp30" with O3 based on sonde Fiji 30 Sep 2000
Replaced (fake) O3 in "myp33" with O3 based on sonde S.Pole 9 Nov 2001
Replaced (fake) O3 in "myp34" with O3 based on sonde S.Pole 30 Apr 1999
Replaced (fake) O3 in "myp35" with O3 based on sonde S.Pole 11 Oct 2001
Replaced (fake) O3 in "myp36" with O3 based on sonde S.Pole 25 Oct 2001
Replaced (fake) O3 in "myp42" with O3 based on sonde S.Pole 17 Sep 2001
Replaced (fake) O3 in "myp43" with O3 based on sonde S.Pole 18 Jul 2001
Replaced (fake) O3 in "myp44" with O3 based on sonde Samoa 8 Feb 1996

Changes to Methane:
-----------------
Replaced CH4 in "myp20" with new CH4
Replaced CH4 in "myp44" with new CH4

