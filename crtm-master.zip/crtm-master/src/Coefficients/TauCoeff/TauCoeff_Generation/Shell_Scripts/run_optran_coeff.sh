gen_optran_coeff.sh ALLCOM optran_coeff.parameters

#get_stat.sh optran_coeff.parameters

EXE_file=${HOME}/gen_tau_coeff_varyingOrder/bin/Cat_tauCoeff
#cat_taucoef.sh optran_coeff.parameters $EXE_file
