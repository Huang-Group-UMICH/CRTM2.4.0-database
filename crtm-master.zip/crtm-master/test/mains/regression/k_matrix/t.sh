cd test_ChannelSubset; ln -s ../../incsrc/*.inc .; cd ..
cd test_ClearSky; ln -s ../../incsrc/*.inc .; cd ..
cd test_ScatteringSwitch; ln -s ../../incsrc/*.inc .; cd ..
cd test_SOI; ln -s ../../incsrc/*.inc .; cd ..
cd test_SSU; ln -s ../../incsrc/*.inc .; cd ..
cd test_VerticalCoordinates; ln -s ../../incsrc/*.inc .; cd ..
cd test_Zeeman; ln -s ../../incsrc/*.inc .; cd ..
cd test_AOD; ln -s ../../incsrc/*.inc .; cd ..
cd test_Simple; ln -s ../../incsrc/*.inc .; cd ..

